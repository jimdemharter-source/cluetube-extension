/* =============================================================================
   TRUEVIEW - REFINED CONTENT SCRIPT
   Quieter, more intentional interactions.
============================================================================= */

(function() {
  'use strict';

  // ---------------------------------------------------------------------------
  // Configuration
  // ---------------------------------------------------------------------------
  const CONFIG = {
    PANEL_CLOSE_KEY: 'Escape',
    SELECTORS: {
      thumbnail: 'ytd-thumbnail, ytd-playlist-thumbnail',
      videoRenderer: 'ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer',
      videoLink: 'a#video-title-link, a#video-title, a.ytd-thumbnail'
    }
  };

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  let currentVideoId = null;
  let panelVisible = false;

  // ---------------------------------------------------------------------------
  // SVG Icons
  // ---------------------------------------------------------------------------
  const ICONS = {
    analyze: `<svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="10"/></svg>`,
    loading: `<svg viewBox="0 0 24 24"><path d="M12 2v4m0 12v4m10-10h-4M6 12H2m15.07-5.07l-2.83 2.83M9.76 14.24l-2.83 2.83m0-10.14l2.83 2.83m4.48 4.48l2.83 2.83"/></svg>`,
    close: `<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`
  };

  // ---------------------------------------------------------------------------
  // Utilities
  // ---------------------------------------------------------------------------
  function extractVideoId(element) {
    // Try to find video ID from various YouTube link patterns
    const links = element.querySelectorAll('a[href*="watch?v="], a[href*="/shorts/"]');
    for (const link of links) {
      const href = link.href;
      const match = href.match(/(?:watch\?v=|\/shorts\/)([a-zA-Z0-9_-]{11})/);
      if (match) return match[1];
    }
    return null;
  }

  function formatTimestamp(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }

  function getVideoUrl(videoId, timestamp = null) {
    let url = `https://www.youtube.com/watch?v=${videoId}`;
    if (timestamp) url += `&t=${Math.floor(timestamp)}s`;
    return url;
  }

  function getThumbnailUrl(videoId) {
    return `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`;
  }

  // ---------------------------------------------------------------------------
  // Cache Badge (visual indicator on analyzed videos)
  // ---------------------------------------------------------------------------
  function addCacheBadge(thumbnail, verdict, videoId) {
    // Remove existing badge if any
    const existing = thumbnail.querySelector('.trueview-cache-badge');
    if (existing) existing.remove();

    const badge = document.createElement('div');
    badge.className = 'trueview-cache-badge';
    badge.dataset.verdict = verdict;
    badge.dataset.videoId = videoId;
    badge.title = `TrueView: ${verdict} clickbait`;
    
    // Click badge to show panel with cached data
    badge.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      showPanelForVideo(videoId, thumbnail);
    });

    thumbnail.style.position = 'relative';
    thumbnail.appendChild(badge);
  }

  // ---------------------------------------------------------------------------
  // Check Button (minimal indicator, always visible)
  // ---------------------------------------------------------------------------
  function createCheckButton(videoId) {
    const btn = document.createElement('button');
    btn.className = 'trueview-check-btn';
    btn.innerHTML = ICONS.analyze;
    btn.title = 'Analyze with TrueView';
    btn.dataset.videoId = videoId;
    btn.addEventListener('click', handleCheckClick);
    return btn;
  }

  function injectCheckButtons() {
    const thumbnails = document.querySelectorAll(CONFIG.SELECTORS.thumbnail);
    
    thumbnails.forEach(thumbnail => {
      // Skip if already has a button or cache badge
      if (thumbnail.querySelector('.trueview-check-btn') || 
          thumbnail.querySelector('.trueview-cache-badge')) {
        return;
      }

      const renderer = thumbnail.closest(CONFIG.SELECTORS.videoRenderer) || thumbnail;
      const videoId = extractVideoId(renderer);
      
      if (!videoId) return;

      // Check if we have cached data for this video
      chrome.storage.local.get(videoId, (items) => {
        if (items[videoId] && Date.now() - items[videoId].timestamp < 24 * 60 * 60 * 1000) {
          // Has valid cache - show badge instead
          addCacheBadge(thumbnail, items[videoId].data.verdict, videoId);
        } else {
          // No cache - show check button
          const btn = createCheckButton(videoId);
          thumbnail.style.position = 'relative';
          thumbnail.appendChild(btn);
        }
      });
    });
  }

  function handleCheckClick(e) {
    e.preventDefault();
    e.stopPropagation();

    const btn = e.currentTarget;
    const thumbnail = btn.closest(CONFIG.SELECTORS.thumbnail);
    const videoId = btn.dataset.videoId;

    if (!videoId) {
      console.error('[TrueView] Could not extract video ID');
      return;
    }

    // Show loading state
    btn.classList.add('loading');
    btn.innerHTML = ICONS.loading;

    showPanelForVideo(videoId, thumbnail);
  }

  // ---------------------------------------------------------------------------
  // Slide-In Panel
  // ---------------------------------------------------------------------------
  function createPanel() {
    // Remove existing panel if any
    const existing = document.querySelector('.trueview-panel');
    if (existing) existing.remove();

    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'trueview-panel-overlay';
    overlay.addEventListener('click', closePanel);

    // Create panel
    const panel = document.createElement('div');
    panel.className = 'trueview-panel';
    panel.innerHTML = `
      <div class="trueview-panel-header">
        <span class="trueview-panel-title">TrueView Analysis</span>
        <button class="trueview-panel-close">${ICONS.close}</button>
      </div>
      <div class="trueview-panel-content">
        <div class="trueview-panel-loading">
          <div class="trueview-spinner"></div>
          <span class="trueview-loading-text">Analyzing video...</span>
        </div>
      </div>
    `;

    panel.querySelector('.trueview-panel-close').addEventListener('click', closePanel);

    document.body.appendChild(overlay);
    document.body.appendChild(panel);

    // Show with animation
    requestAnimationFrame(() => {
      overlay.classList.add('visible');
      panel.classList.add('visible');
    });

    panelVisible = true;
    return panel;
  }

  function closePanel() {
    const panel = document.querySelector('.trueview-panel');
    const overlay = document.querySelector('.trueview-panel-overlay');

    if (panel) {
      panel.classList.remove('visible');
      setTimeout(() => panel.remove(), 350);
    }
    if (overlay) {
      overlay.classList.remove('visible');
      setTimeout(() => overlay.remove(), 300);
    }

    panelVisible = false;
    currentVideoId = null;

    // Reset any loading buttons
    document.querySelectorAll('.trueview-check-btn.loading').forEach(btn => {
      btn.classList.remove('loading');
      btn.innerHTML = `${ICONS.analyze}<span>Check</span>`;
    });
  }

  function renderPanelContent(data, videoId, videoTitle) {
    const panel = document.querySelector('.trueview-panel');
    if (!panel) return;

    const content = panel.querySelector('.trueview-panel-content');
    
    // Build takeaways HTML
    const takeawaysHtml = data.keyPoints.map(point => `
      <li class="trueview-takeaway">
        <span class="trueview-takeaway-emoji">${point.emoji || '•'}</span>
        <div class="trueview-takeaway-content">
          <p class="trueview-takeaway-text">${point.text}</p>
          ${point.timestamp ? `
            <a href="${getVideoUrl(videoId, point.timestamp)}" 
               class="trueview-takeaway-timestamp" 
               target="_blank">
              ${formatTimestamp(point.timestamp)}
            </a>
          ` : ''}
        </div>
      </li>
    `).join('');

    content.innerHTML = `
      <div class="trueview-video-preview">
        <img src="${getThumbnailUrl(videoId)}" alt="" class="trueview-video-thumb">
        <div class="trueview-video-info">
          <a href="${getVideoUrl(videoId)}" target="_blank" class="trueview-video-title">
            ${videoTitle || 'Video'}
          </a>
          <span class="trueview-verdict-badge" data-verdict="${data.verdict}">
            ${data.verdict} Clickbait
          </span>
        </div>
      </div>

      ${data.clickbaitReason ? `
        <p class="trueview-clickbait-reason">"${data.clickbaitReason}"</p>
      ` : ''}

      <div class="trueview-section">
        <h3 class="trueview-section-header">📌 Key Takeaways</h3>
        <ul class="trueview-takeaways">
          ${takeawaysHtml}
        </ul>
      </div>

      <div class="trueview-conclusion">
        <div class="trueview-conclusion-label">So what?</div>
        <p class="trueview-conclusion-text">${data.conclusion}</p>
      </div>
    `;
  }

  function renderPanelError(message) {
    const panel = document.querySelector('.trueview-panel');
    if (!panel) return;

    const content = panel.querySelector('.trueview-panel-content');
    content.innerHTML = `
      <div class="trueview-panel-error">
        <div class="trueview-error-icon">⚠️</div>
        <p class="trueview-error-message">${message}</p>
        <button class="trueview-retry-btn">Try Again</button>
      </div>
    `;

    content.querySelector('.trueview-retry-btn').addEventListener('click', () => {
      if (currentVideoId) {
        content.innerHTML = `
          <div class="trueview-panel-loading">
            <div class="trueview-spinner"></div>
            <span class="trueview-loading-text">Analyzing video...</span>
          </div>
        `;
        analyzeVideo(currentVideoId);
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Analysis Flow
  // ---------------------------------------------------------------------------
  async function showPanelForVideo(videoId, thumbnail) {
    currentVideoId = videoId;
    
    // Get video title from thumbnail context
    const renderer = thumbnail?.closest(CONFIG.SELECTORS.videoRenderer) || thumbnail;
    const titleEl = renderer?.querySelector('#video-title, #video-title-link, .title');
    const videoTitle = titleEl?.textContent?.trim() || '';

    // Create and show panel
    createPanel();

    // Check cache first
    chrome.storage.local.get(videoId, (items) => {
      if (items[videoId]) {
        const cached = items[videoId];
        if (Date.now() - cached.timestamp < 24 * 60 * 60 * 1000) {
          // Use cached data
          renderPanelContent(cached.data, videoId, videoTitle);
          resetCheckButton(thumbnail);
          return;
        }
      }
      // Fetch fresh analysis
      analyzeVideo(videoId, videoTitle, thumbnail);
    });
  }

  async function analyzeVideo(videoId, videoTitle = '', thumbnail = null) {
    try {
      // Request analysis from background script
      const response = await chrome.runtime.sendMessage({
        action: 'analyzeTranscript',
        videoId: videoId
      });

      if (response.success) {
        renderPanelContent(response.data, videoId, videoTitle);
        
        // Replace check button with cache badge
        if (thumbnail) {
          const btn = thumbnail.querySelector('.trueview-check-btn');
          if (btn) btn.remove();
          addCacheBadge(thumbnail, response.data.verdict, videoId);
        }
      } else {
        renderPanelError(response.error || 'Analysis failed. Please try again.');
        resetCheckButton(thumbnail);
      }
    } catch (err) {
      console.error('[TrueView] Analysis error:', err);
      renderPanelError('Could not connect to analysis service.');
      resetCheckButton(thumbnail);
    }
  }

  function resetCheckButton(thumbnail) {
    if (!thumbnail) return;
    const btn = thumbnail.querySelector('.trueview-check-btn');
    if (btn) {
      btn.classList.remove('loading');
      btn.innerHTML = ICONS.analyze;
    }
  }

  // ---------------------------------------------------------------------------
  // Event Handlers
  // ---------------------------------------------------------------------------
  function handleKeyDown(e) {
    // Close panel with Escape
    if (e.key === CONFIG.PANEL_CLOSE_KEY && panelVisible) {
      closePanel();
    }
  }

  // ---------------------------------------------------------------------------
  // Initialization
  // ---------------------------------------------------------------------------
  function init() {
    console.log('[TrueView] Initializing refined UI...');

    // Keyboard shortcuts (Escape to close)
    document.addEventListener('keydown', handleKeyDown);

    // Inject check buttons on all visible thumbnails
    injectCheckButtons();

    // Observe for dynamically loaded content
    const observer = new MutationObserver((mutations) => {
      let shouldInject = false;
      for (const mutation of mutations) {
        if (mutation.addedNodes.length) {
          shouldInject = true;
          break;
        }
      }
      if (shouldInject) {
        // Debounce injection
        clearTimeout(observer.injectTimeout);
        observer.injectTimeout = setTimeout(injectCheckButtons, 300);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    // Context menu integration
    setupContextMenu();
  }

  function setupContextMenu() {
    // Listen for context menu trigger from background
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === 'analyzeFromContextMenu') {
        const videoId = message.videoId;
        if (videoId) {
          showPanelForVideo(videoId, null);
        }
      }
    });
  }

  // Start when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
